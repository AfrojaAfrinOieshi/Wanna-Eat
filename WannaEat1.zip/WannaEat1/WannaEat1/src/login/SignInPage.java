package login;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author USER
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.*;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JOptionPane;
import sun.audio.AudioPlayer;
import sun.audio.AudioStream;


public class SignInPage extends javax.swing.JFrame {

    /**
     * Creates new form SignInPage
     */
    public Receipt Receipt;
    public SelectOne SelectOne;
    public Connection cn;
    public Statement st;

    public SignInPage() {

        initComponents();
        try {

            Class.forName("com.mysql.jdbc.Driver");

            cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/enter", "root", "");
            st = cn.createStatement();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Not Connected");
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        namesign = new javax.swing.JTextField();
        password = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();
        Email = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1050, 660));
        setMinimumSize(new java.awt.Dimension(1050, 660));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Utsaah", 1, 36)); // NOI18N
        jLabel1.setText("Name        :");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 200, 140, 33));

        jLabel2.setFont(new java.awt.Font("Utsaah", 1, 36)); // NOI18N
        jLabel2.setText("Password :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 250, 140, 34));

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButton1.setText("Sign In");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 340, 110, 40));

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButton2.setText("Log In");
        jButton2.setBorder(null);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 340, 120, 40));

        jButton3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButton3.setText("Reset");
        jButton3.setBorder(null);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 340, 120, 40));

        jButton4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jButton4.setText("Exit");
        jButton4.setBorder(null);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 340, 120, 40));
        getContentPane().add(namesign, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 200, 370, 30));
        getContentPane().add(password, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 250, 370, 30));

        jLabel4.setFont(new java.awt.Font("Utsaah", 1, 36)); // NOI18N
        jLabel4.setText("E-mail       :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 150, -1, -1));
        getContentPane().add(Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 150, 370, 30));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/login/backgroundSignIn.jpg"))); // NOI18N
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1050, 660));

        pack();
    }// </editor-fold>//GEN-END:initComponents

  
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:

        try {
            String sql = "select *from food where Email='" + Email.getText() + "'and name ='" + namesign.getText() + "'and password ='" + String.valueOf(password.getPassword()) + "'";
            ResultSet rss = st.executeQuery(sql);
            if (rss.next()) {
                sound_welcome();
                JOptionPane.showMessageDialog(null, "Welcome");
                SelectOne = new SelectOne();
                SelectOne.nameselect.setText(SignInPage.namesign.getText());
                SelectOne.setVisible(true);
                this.dispose();

            } else {
                 sound_error();
                JOptionPane.showMessageDialog(null, "Failed Login");
               
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error Occured in procedure");

        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Email.setText(null);
        namesign.setText(null);
        password.setText(null);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void sound_error(){
        try{
            File sound;
            sound = new File("C:\\Users\\USER\\Downloads\\Compressed\\WannaEat1\\WannaEat1\\music\\error.wav");
            Clip c=AudioSystem.getClip();
            c.open(AudioSystem.getAudioInputStream(sound));
            c.start();
        }catch(Exception e){    
        }
    }
    private void sound_welcome(){
        try{
            File sound;
            sound = new File("C:\\Users\\USER\\Downloads\\Compressed\\WannaEat1\\WannaEat1\\music\\welcome.wav");
            Clip c=AudioSystem.getClip();
            c.open(AudioSystem.getAudioInputStream(sound));
            c.start();
        }catch(Exception e){    
        }
    }
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/enter", "root", "");

            String sql = "insert into food values(? ,? , ?)";
            PreparedStatement pstmt = conn.prepareCall(sql);
            pstmt.setString(1, Email.getText());
            pstmt.setString(2, namesign.getText());
            pstmt.setString(3, String.valueOf(password.getPassword()));

            if (Email.getText().equals("") || namesign.getText().equals("") || String.valueOf(password.getPassword()).equals("")) {
                sound_error();
                JOptionPane.showMessageDialog(null, "Please fulfill the requirements properly");

            } else {
                if (Email.getText().contains("@") && Email.getText().contains(".com")) {
                    pstmt.executeUpdate();
                    sound_welcome();
                    JOptionPane.showMessageDialog(null, "Welcome!!!");
                    
                    SelectOne = new SelectOne();
                    SelectOne.nameselect.setText(SignInPage.namesign.getText());
                    
                    conn.close();
                    SelectOne.setVisible(true);
                    this.dispose();
                } else {
                    sound_error();
                    JOptionPane.showMessageDialog(null, "Invalid Email ID");
                    
                }

            }

            //JOptionPane.showMessageDialog(null, "Insertion successful");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SignInPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SignInPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SignInPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SignInPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SignInPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Email;
    public static javax.swing.JButton jButton1;
    public static javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    public static javax.swing.JTextField namesign;
    private javax.swing.JPasswordField password;
    // End of variables declaration//GEN-END:variables
}
